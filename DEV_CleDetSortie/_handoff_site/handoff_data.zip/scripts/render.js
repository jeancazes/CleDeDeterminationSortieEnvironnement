const {chromium}=require('playwright');
(async()=>{
 const b=await chromium.launch();
 for (const [n,N] of [['livret',76]]){
  const p=await b.newPage({viewport:{width:559,height:794},deviceScaleFactor:2});
  await p.goto('file://'+process.cwd()+'/build/'+n+'.html',{waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready);
  await p.pdf({path:'build/'+n+'.pdf',width:'559px',height:'794px',printBackground:true});
  const secs=await p.$$('section.pg');
  require('fs').mkdirSync('build/pages_'+n,{recursive:true});
  for(let i=0;i<secs.length;i++){await secs[i].screenshot({path:`build/pages_${n}/p${String(i+1).padStart(2,'0')}.jpg`,type:'jpeg',quality:82});}
  const ov=await p.evaluate(()=>[...document.querySelectorAll('section.pg')].map((s,i)=>{const r=s.getBoundingClientRect();let bad=0;s.querySelectorAll('*').forEach(e=>{const q=e.getBoundingClientRect();if(q.bottom>r.bottom+1&&q.height>0)bad++});return bad?i+1:0}).filter(x=>x));
  console.log(n,secs.length,'overflow pages',ov);
 }
 await b.close();
})();
