import re,os
L='live2/project/'
FILES={int(re.match(r'a5-p(\d+)',f).group(1)):f for f in os.listdir(L) if f.startswith('a5-p')}
def rdp(p): return open(L+FILES[p]).read()
CARD=re.compile(r'font-size: 12px">(\d+)</div><div style="flex-grow: 1; min-height: 0; position: relative"><div style="position: absolute; top: 20px; right: 2px; bottom: 3px; left: 2px">(.*?)</div></div><div style="font-size: [\d.]+px; font-weight: 700; line-height: 1.2">(.*?)</div><div style="font-family: \'Fraunces\', Georgia, serif; font-size: [\d.]+px; line-height: [\d.]+">(.*?)</div><div style="font-size: [\d.]+px; line-height: [\d.]+; color: #55554F">(.*?)</div>',re.S)
def species(pages):
    d={}
    for p in pages:
        for n,pic,name,lat,cap in CARD.findall(rdp(p)):
            m=re.search(r'/_blob/([0-9a-f]{32})',pic)
            d[int(n)]=(name,lat,cap,m.group(1) if m else None)
    return d
OPT=re.compile(r'width: 12px; color: #55554F; flex-shrink: 0">([ab])</span><div[^>]*><span>(.*?)</span><span style="flex-grow: 1; min-width: 10px[^>]*></span>(.*?)</div></div>',re.S)
def couplets(pages):
    d={}
    for p in pages:
        s=rdp(p)
        parts=re.split(r'font-size: 16px; background: #FFFFFF">(\d+)</div>',s)
        for i in range(1,len(parts),2):
            n=int(parts[i]); opts=OPT.findall(parts[i+1])[:2]
            c=[]
            for l,t,res in opts:
                mx=re.search(r'background: #F1F0EA">(.*?) <span[^>]*>p\. (\d+)</span>',res)
                if mx:
                    c.append((t,('ext',mx.group(1),int(mx.group(2)))))
                elif 'va à' in res:
                    c.append((t,('go',int(re.search(r'color: #1B1B18">(\d+)</span>',res).group(1)))))
                else:
                    c.append((t,('sp',int(re.search(r'font-size: 11.5px">(\d+)</span>',res).group(1)))))
            assert len(c)==2,(p,n)
            d[n]=tuple(c)
    return d
if __name__=='__main__':
    for nm,kp,pp in (('foret',[6,8,10,12],[7,9,11,13]),('ripi',[22,24,26,28],[23,25,27,29])):
        sp=species(pp); cp=couplets(kp)
        print(nm,len(sp),len(cp),sorted(sp)==list(range(1,len(sp)+1)),sorted(cp)==list(range(1,len(cp)+1)))
        tgt={r[1] for c in cp.values() for t,r in c if r[0]=='sp'}
        print(' species not reached:',set(sp)-tgt, ' no image:',[n for n,v in sp.items() if not v[3]])
        print(' ',cp[1])
