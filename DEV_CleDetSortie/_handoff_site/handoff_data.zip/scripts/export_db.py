import json,re,os,html,shutil,unicodedata
from PIL import Image
import parse_veg as P
def setL(L):
    P.L=L; P.FILES={int(re.match(r'a5-p(\d+)',f).group(1)):f for f in os.listdir(L) if f.startswith('a5-p')}
setL('out11/project/')
loc=json.load(open('loc2.json'))
strip=lambda t: html.unescape(re.sub(r'\s+',' ',re.sub(r'<[^>]+>','',t))).strip()
slug=lambda t: re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',''.join(c for c in unicodedata.normalize('NFD',t.lower()) if unicodedata.category(c)!='Mn'))).strip('-')
BIOMES=[('foret',"Forêt de l'Ancyse",'Forêt'),('ripi','Ripisylve','Ripisylve'),('riv','Rivière (la Cèze)','Rivière')]
SEC=[('foret','vegetaux',list(range(6,23,2)),list(range(7,24,2))),('foret','npa',[24,26],[25,27]),('foret','animaux',[28,30,32,34,36],[29,31,33,35,37]),('foret','traces',[38,40,42],[39,41,43]),
('ripi','vegetaux',list(range(44,55,2)),list(range(45,56,2))),('ripi','animaux',[56,58],[57,59]),('ripi','traces',[60],[61]),
('riv','vegetaux',[62,64],[63,65]),('riv','animaux',[66,68,70],[67,69,71]),('riv','traces',[72],[73])]
LABEL={'vegetaux':'Végétaux','npa':'Champignons et lichens','animaux':'Animaux','traces':'Traces'}
BM={}
def img(b,name,m,k):
    if not b: return ''
    if b in BM: return BM[b]
    fn='images/%s-%s-%s.jpg'%(m,k,slug(name))
    im=Image.open(loc[b]).convert('RGB'); im.thumbnail((1024,1024)); im.save('handoff/'+fn,quality=88,optimize=True)
    BM[b]=fn; return fn
def ext_target(m,lab):
    if 'traces' in lab: return m+'-traces'
    if 'animaux' in lab or 'petites' in lab: return m+'-animaux'
    if 'Champignons' in lab: return 'foret-npa'
DB={'title':'Qui vit ici ?','subtitle':"Clés de détermination — forêt de l'Ancyse, ripisylve et rivière Cèze (Bagnols-sur-Cèze)",'level':'6e',
    'biomes':[{'id':i,'name':n,'tab':t,'keys':[]} for i,n,t in BIOMES]}
BI={b['id']:b for b in DB['biomes']}
def add_key(m,k,kp,pp,src=None,extra_online=None):
    if src: setL(src)
    sp=P.species(pp); cp=P.couplets(kp)
    s=open(P.L+P.FILES[kp[0]]).read(); i=s.find('<h1'); h=s[i:i+1500]
    mm=re.search(r'<p[^>]*>(.*?)</p>',h,re.S); intro=strip(mm.group(1)) if mm else ''
    title=strip(re.search(r'<h1[^>]*>(.*?)</h1>',h,re.S).group(1)) if '<h1' in h else ''
    return sp,cp,intro,title
for m,k,kp,pp in SEC:
    sp,cp,intro,title=add_key(m,k,kp,pp)
    page={}
    for p in pp:
        for n in re.findall(r'font-size: 12px">(\d+)</div><div style="flex-grow: 1',open(P.L+P.FILES[p]).read()): page[int(n)]=p
    key={'type':k,'label':LABEL[k] if not (m=='riv' and k=='animaux') else 'Petites bêtes','title':title,'intro':intro,'root':1,
         'couplets':{str(n):[([strip(t),'ext',ext_target(m,r[1]),strip(r[1]),r[2]] if r[0]=='ext' else [strip(t),r[0],r[1]]) for t,r in c] for n,c in cp.items()},
         'species':{str(n):{'id':'%s-%s-%s'%(m,k,slug(strip(v[0]))),'name':strip(v[0]),'lat':strip(v[1]),'cap':strip(v[2]),'image':img(v[3],strip(v[0]),m,k),'print':True,'online':True,'print_page':page[n]} for n,v in sp.items()}}
    BI[m]['keys'].append(key)
setL('out11/project/')
# online-complete versions (species removed from print)
def keyof(m,k): return [x for x in BI[m]['keys'] if x['type']==k][0]
FULL={('foret','traces'):([36,38,40],[37,39,41]),('ripi','traces'):([58,60],[59,61])}
for (m,k),(kp,pp) in FULL.items():
    setL('out9/project/'); sp=P.species(pp); cp=P.couplets(kp)
    old=keyof(m,k); byname={s['name']:s for s in old['species'].values()}
    old['couplets']={str(n):[([strip(t),'ext',ext_target(m,r[1]),strip(r[1]),r[2]] if r[0]=='ext' else [strip(t),r[0],r[1]]) for t,r in c] for n,c in cp.items()}
    ns={}
    for n,v in sp.items():
        nm=strip(v[0])
        if nm in byname: ns[str(n)]=byname[nm]
        else: ns[str(n)]={'id':'%s-%s-%s'%(m,k,slug(nm)),'name':nm,'lat':strip(v[1]),'cap':strip(v[2]),'image':img(v[3],nm,m,k),'print':False,'online':True,'print_page':None}
    old['species']=ns
on=json.load(open('online11.json'))['foret-vegetaux']; fv=keyof('foret','vegetaux')
fv['couplets']={n:[([c[0],'ext',ext_target('foret',c[2]),c[2],c[3]] if c[1]=='ext' else c) for c in cc] for n,cc in on['couplets'].items()}
for n,s in on['extra'].items():
    fv['species'][n]={'id':'foret-vegetaux-'+slug(s['name']),'name':s['name'],'lat':s['lat'],'cap':s['cap'],'image':img(s['blob'],s['name'],'foret','vegetaux') if s['blob'] else '','print':False,'online':True,'print_page':None}
# checks
for b in DB['biomes']:
    for kk in b['keys']:
        reach={str(c[2]) for cc in kk['couplets'].values() for c in cc if c[1]=='sp'}
        assert reach==set(kk['species']),(b['id'],kk['type'],reach^set(kk['species']))
json.dump(DB,open('handoff/livret_db.json','w'),ensure_ascii=False,indent=1)
n=sum(len(k['species']) for b in DB['biomes'] for k in b['keys']); print('species',n,'images',len(os.listdir('handoff/images')))
print([(s['name']) for b in DB['biomes'] for k in b['keys'] for s in k['species'].values() if not s['print']])
print([(s['name']) for b in DB['biomes'] for k in b['keys'] for s in k['species'].values() if not s['image']])

import glob
os.makedirs('handoff/images/pages',exist_ok=True)
for f in sorted(glob.glob('out11/project/*')):
    h=open(f).read(); shutil.copy(f,'handoff/livret_pages/')
    for b in re.findall(r'/_blob/([0-9a-f]{32})',h):
        if b not in BM:
            fn='images/pages/%s.jpg'%b
            im=Image.open(loc[b]).convert('RGB'); im.thumbnail((1400,1400)); im.save('handoff/'+fn,quality=88); BM[b]=fn
json.dump(BM,open('handoff/livret_pages/blob_map.json','w'),indent=1)
print('blob map',len(BM))
