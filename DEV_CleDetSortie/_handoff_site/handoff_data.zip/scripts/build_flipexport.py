import re,os,json,base64,html
from PIL import Image
from io import BytesIO
D='out11/project/'
cj=json.load(open(D+'canvas.json'))
files=sorted(f for f in os.listdir(D) if f.startswith('a5-p'))
assert len(files)==76
titles=[cj['boards'][f]['title'].split(' · ',1)[1] for f in files]
CARD=re.compile(r'font-size: 12px">(\d+)</div><div style="flex-grow: 1; min-height: 0; position: relative">.*?<div style="font-size: [\d.]+px; font-weight: 700; line-height: 1.2">(.*?)</div><div style="font-family: \'Fraunces\', Georgia, serif; font-size: [\d.]+px; line-height: [\d.]+">(.*?)</div><div style="font-size: [\d.]+px; line-height: [\d.]+; color: #55554F">(.*?)</div>',re.S)
strip=lambda t: html.unescape(re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',t))).strip()
species=[]; texts=[]
for i,f in enumerate(files):
    s=open(D+f).read()
    body=s[s.find('</helmet>'):s.find('</x-dc>')]
    texts.append(strip(body))
    milieu=titles[i].split(' : ')[0] if ' : ' in titles[i] else ''
    for n,name,lat,cap in CARD.findall(body):
        species.append({'n':int(n),'name':strip(name),'lat':strip(lat),'cap':strip(cap),'p':i+1,'m':milieu,'kind':titles[i].split(' : ')[1].split(' (')[0].replace('Planche des ','') if ' : ' in titles[i] else ''})
print(len(species),'species/traces')
pages=[]
for i in range(76):
    im=Image.open('build/pages_livret/p%02d.jpg'%(i+1)).convert('RGB')
    im=im.resize((900,1278),Image.LANCZOS)
    b=BytesIO(); im.save(b,'JPEG',quality=80,optimize=True)
    pages.append('data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode())
TOC=[('Début',[(1,'Couverture'),(2,'Comment utiliser ce carnet'),(3,'Deux noms pour chaque être vivant'),(4,'Le paysage'),(5,'Règles et sommaire')]),
 ("Forêt de l'Ancyse",[(6,'Clé de la forêt (départ)'),(7,'Planches des végétaux (p. 7 à 23)'),(24,'Champignons et lichens : clé'),(25,'Planche des champignons'),(27,'Planche des lichens'),(28,'Clé des animaux'),(29,'Planches des animaux (p. 29 à 37)'),(38,'Clé des traces'),(39,'Planches des traces')]),
 ('Ripisylve',[(44,'Clé de la ripisylve (départ)'),(45,'Planches des végétaux'),(56,'Clé des animaux'),(57,'Planches des animaux'),(60,'Clé des traces'),(61,'Planche des traces')]),
 ('Rivière (la Cèze)',[(62,'Clé de la rivière (départ)'),(63,'Planches des végétaux'),(66,'Clé des petites bêtes'),(67,'Planches des petites bêtes'),(72,'Clé des traces'),(73,'Planche des traces')]),
 ('Pour finir',[(74,"Quelle est la qualité de l'eau ?"),(75,'Mots à connaître'),(76,'À ne pas toucher')])]
data=dict(titles=titles,texts=texts,species=species,toc=TOC)
pf=open('pf/package/dist/js/page-flip.browser.js').read()
tpl=open('flip_export_tpl.html').read()
out=tpl.replace('/*KEYS*/','window.KEYS='+open('keys_data.json').read()+';').replace('/*PAGEFLIP*/',pf).replace('/*DATA*/','window.LIVRET='+json.dumps(data,ensure_ascii=False)+';window.PAGES='+json.dumps(pages)+';')
open('/mnt/user-data/outputs/Livret_Ancyse_Ceze_interactif.html','w').write(out)
print(os.path.getsize('/mnt/user-data/outputs/Livret_Ancyse_Ceze_interactif.html')/1e6,'MB')
