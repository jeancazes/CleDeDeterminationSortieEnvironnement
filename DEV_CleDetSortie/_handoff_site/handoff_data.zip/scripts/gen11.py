import re, json, os, shutil, subprocess
SPD=os.getcwd()
src=open('gen.py').read()
exec(src[:src.index('# ------------------------------------------------------------------ data')])
import parse_veg as P
P.L=L='out10/project/'
FILES=P.FILES={int(re.match(r'a5-p(\d+)',f).group(1)):f for f in os.listdir(L) if f.startswith('a5-p')}
def rd(name): return open(os.path.join(L,name)).read()
def rdp(p): return rd(FILES[p])
B={}
def wb(t):
    a,b,c,bl=t
    if bl: B['b:'+bl]=bl; return (a,b,c,'b:'+bl)
    return (a,b,c,None)
_opt=opt_html
def opt_html(letter,text,res,ctx):
    if res[0]!='ext': return _opt(letter,text,res,ctx)
    r=('<span style="display: inline-flex; align-items: center; gap: 4px; white-space: nowrap; font-weight: 700; font-size: 13.5px; border: 1.5px solid #1B1B18; '
       'border-radius: 5px; padding: 1px 7px; background: #F1F0EA">%s <span style="font-weight: 400; color: #55554F; font-size: 12.5px">p. %d</span></span>')%(res[1],res[2])
    base=_opt(letter,text,('go',0),dict(ctx,balpage={0:ctx['page']}))
    i=base.index('margin-bottom: 6px"></span>')+len('margin-bottom: 6px"></span>'); j=base.rindex('</div></div>')
    return base[:i]+r+base[j:]
def remap(p):
    if p<=25 or p>=62: return p
    if 26<=p<=57: return p+2
    if 58<=p<=61: return 60 if p in (58,60) else 61
    raise ValueError(p)
def remap_refs(s):
    s=re.sub(r'(font-weight: 700; font-size: 15px">)(\d+)(</div>)',lambda m:m.group(1)+str(remap(int(m.group(2))))+m.group(3),s)
    s=re.sub(r'(page |p\. )(\d+)',lambda m:m.group(1)+str(remap(int(m.group(2)))),s)
    return s
def number(sym, root):
    order=[]
    def walk(i):
        if i in order: return
        order.append(i)
        for t,r in sym[i]:
            if r[0]=='go': walk(r[1])
    walk(root)
    num={i:k+1 for k,i in enumerate(order)}
    return {num[i]:tuple((t,('go',num[r[1]]) if r[0]=='go' else r) for t,r in sym[i]) for i in order}
def remove_species(K,sp,name):
    rm=[n for n,v in sp.items() if re.sub('<[^>]+>','',v[0])==name]; assert len(rm)==1,name; rm=rm[0]
    K=dict(K)
    c=[n for n,cc in K.items() if any(r==('sp',rm) for t,r in cc)]; assert len(c)==1; c=c[0]
    other=[r for t,r in K[c] if r!=('sp',rm)][0]
    del K[c]
    K={n:tuple((t,other if r==('go',c) else r) for t,r in cc) for n,cc in K.items()}
    root=min(K) if c!=1 else (other[1] if other[0]=='go' else None)
    sp={n:v for n,v in sp.items() if n!=rm}
    order=sorted(sp); ren={o:i+1 for i,o in enumerate(order)}
    sp={ren[o]:v for o,v in sp.items()}
    K={n:tuple((t,('sp',ren[r[1]]) if r[0]=='sp' else r) for t,r in cc) for n,cc in K.items()}
    K=number(K,root if root else min(K))
    return K,sp
# ---------- optimiser (from gen9)
def meas_heights(sections):
    meas=[]
    for name,(sp,K) in sections.items():
        names={n:v[0] for n,v in sp.items()}
        ctx=dict(page=-10,names=names,sppage={n:-9 for n in sp},balpage={n:-10 for n in K})
        for n in sorted(K): meas.append((name,n,couplet_html(n,K[n],False,ctx)))
    html='<html><head><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;1,9..144,400;1,9..144,500&display=swap"></head><body style="margin:0;font-family:\'Atkinson Hyperlegible\',\'Trebuchet MS\',sans-serif">'
    html+=''.join('<div class="m" style="width:467px;display:flex;flex-direction:column" data-k="%s|%d">%s</div>'%(a,n,h) for a,n,h in meas)+'</body></html>'
    open('build/meas.html','w').write(html); subprocess.run(['node','build/meas.js'],check=True)
    return {k:h for k,h in json.load(open('build/meas.json'))}
def optimise(name,sp,K,k,cap,H):
    cn=sorted(K); N=len(cn)
    h=[H['%s|%d'%(name,n)] for n in cn]
    res=[[x[1] for t,x in K[n] if x[0]=='sp'] for n in cn]
    def lim(i): return (702-124 if i==0 else 702-64) - (0 if i==k-1 else 24) - 8 + (60 if (name=='fveg' and i==0) else 0)
    from functools import lru_cache
    @lru_cache(None)
    def dp(i,start):
        if i==k: return (0,()) if start==N else (1e9,())
        best=(1e9,()); tot=0
        for end in range(start+1,N+1):
            tot+=h[end-1]
            if tot>lim(i): break
            if k-i-1>N-end: break
            r=set(x for j in range(start,end) for x in res[j])
            c=max(0,len(r)-cap)*10+(30 if not r else 0)+((lim(i)-tot)/lim(i))**2*0.5
            sub=dp(i+1,end)
            if c+sub[0]<best[0]: best=(c+sub[0],(end-start,)+sub[1])
        return best
    cost,split=dp(0,0); assert split,name
    pages=[];idx=0;done=set()
    for s in split:
        lst=[]
        for j in range(idx,idx+s):
            for x in res[j]:
                if x not in done: done.add(x); lst.append(x)
        pages.append(lst); idx+=s
    pl=[l[:cap] for l in pages]
    for i,l in enumerate(pages):
        for x in l[cap:]:
            for d in (1,-1,2,-2,3,-3):
                j=i+d
                if 0<=j<k and len(pl[j])<cap: pl[j].append(x); break
    order=[x for l in pl for x in l]; ren={o:i+1 for i,o in enumerate(order)}
    sp2={ren[o]:sp[o] for o in sp}
    K2={n:tuple((t,('sp',ren[x[1]]) if x[0]=='sp' else x) for t,x in c) for n,c in K.items()}
    print(name,'split',split,'planches',[len(l) for l in pl],'hits',sum(1 for i in range(k) for x in pages[i] if x in pl[i]),'/',len(sp))
    return list(split),[len(l) for l in pl],sp2,K2

OLDTITLE={p:re.search(r'<title>(.*?)</title>',rdp(p)).group(1) for p in FILES}
S=lambda l:'<i>%s</i>'%l
sp={n:wb(v) for n,v in P.species(list(range(7,24,2))).items()}
K=P.couplets(list(range(6,23,2)))
num_of={re.sub('<[^>]+>','',v[0]):n for n,v in sp.items()}
BAR=num_of['Barbon pied-de-poule']; BRA=num_of['Brachypode rameux']
barbon=sp.pop(BAR)
NEWSP={'Grande brize':(S('Briza maxima'),'Épillets en cœur qui tremblent'),
       'Aphyllanthe de Montpellier':(S('Aphyllanthes monspeliensis'),'Touffe de « joncs » bleu-vert, fleur bleue'),
       'Laîche de Haller':(S('Carex halleriana'),'Tige à 3 angles, sous les chênes verts')}
nx=max(list(sp)+[BAR])+1; ids={}
for nm,(la,cap) in NEWSP.items(): sp[nx]=(nm,la,cap,None); ids[nm]=nx; nx+=1
sym={('o%d'%n):tuple((t,('go','o%d'%r[1]) if r[0]=='go' else r) for t,r in c) for n,c in K.items()}
assert sym['o11'][0][1]==('go','o12')
sym['o11']=(("Herbe en touffe : longues feuilles en ruban, ou tiges fines comme du jonc",('go','g1')),sym['o11'][1])
del sym['o12']
sym['g1']=(("Touffe de tiges fines bleu-vert, sans vraies feuilles, fleurs bleues au printemps",('sp',ids['Aphyllanthe de Montpellier'])),("De longues feuilles en ruban",('go','g2')))
sym['g2']=(("Tige à 3 angles, sans nœuds, petits épis bruns",('sp',ids['Laîche de Haller'])),("Tige ronde et creuse, avec des nœuds : une graminée",('go','g3')))
sym['g3']=(("Épillets gonflés en forme de cœur, qui pendent et tremblent",('sp',ids['Grande brize'])),("1 à 3 épis plats et étroits au bout de tiges ramifiées",('sp',BRA)))
K1=number(sym,'o1')
tg={r[1] for c in K1.values() for t,r in c if r[0]=='sp'}; assert tg==set(sp),(tg^set(sp))
H=meas_heights({'fveg':(sp,K1)})
ks,ps,sp2,K2=optimise('fveg',sp,K1,9,4,H)
kp=list(range(6,23,2))
f,_=build_section(dict(key1=FILES[6],keyN=FILES[8],pl1=FILES[7],plN=FILES[9]),kp,[p+1 for p in kp],sp2,K2,ks,ps,"x","y")
NEW={p:rdp(p) for p in FILES}
for p,hh in f.items(): NEW[p]=re.sub(r'<title>.*?</title>','<title>%s</title>'%OLDTITLE[p],hh,count=1)
# online version: brachypode result -> extra couplet barbon / brachypode
bra2=[n for n,v in sp2.items() if v[0]=='Brachypode rameux'][0]
bar2=max(sp2)+1; c2=max(K2)+1
Kon={n:tuple((t,('go',c2) if r==('sp',bra2) else r) for t,r in c) for n,c in K2.items()}
Kon[c2]=(("Épis fins et soyeux, groupés en éventail au bout de la tige",('sp',bar2)),("1 à 3 épis plats et étroits au bout de tiges ramifiées",('sp',bra2)))
strip=lambda t: re.sub(r'\s+',' ',re.sub(r'<[^>]+>','',t)).strip()
json.dump({'foret-vegetaux':{'couplets':{str(n):[[strip(t)]+list(r) for t,r in c] for n,c in Kon.items()},
  'extra':{str(bar2):{'name':strip(barbon[0]),'lat':strip(barbon[1]),'cap':strip(barbon[2]),'blob':barbon[3][2:] if barbon[3] else ''}}}},open('online11.json','w'),ensure_ascii=False)
# ext couplets need label/page in online format
OUT=SPD+'/out11/project'
if os.path.exists(SPD+'/out11'): shutil.rmtree(SPD+'/out11')
shutil.copytree(L,OUT)
ch=[]
for p,hh in NEW.items():
    if hh!=rdp(p): open(os.path.join(OUT,FILES[p]),'w').write(hh); ch.append(FILES[p])
json.dump(ch,open('changed11.json','w')); print(len(ch),'pages changed')
