from pypdf import PdfReader, PdfWriter, Transformation, PageObject
import sys
src,out,W,H=sys.argv[1],sys.argv[2],float(sys.argv[3]),float(sys.argv[4])
r=PdfReader(src); N=len(r.pages); assert N%4==0
w=PdfWriter()
def side(l,rp):
    pg=PageObject.create_blank_page(width=W,height=H)
    for i,p in enumerate((l,rp)):
        sp=r.pages[p-1]; pw=float(sp.mediabox.width); ph=float(sp.mediabox.height)
        s=min((W/2)/pw,H/ph); x=i*W/2+((W/2)-pw*s)/2; y=(H-ph*s)/2
        pg.merge_transformed_page(sp,Transformation().scale(s).translate(x,y))
    w.add_page(pg)
for k in range(N//4):
    side(N-2*k,2*k+1); side(2*k+2,N-2*k-1)
w.write(out)
