import re,os,json,sys
from PIL import Image
SP=os.getcwd(); SRCDIR=sys.argv[1] if len(sys.argv)>1 else 'live2/project'
loc=json.load(open('loc2.json'))
def small(b):
    out='build/img/%s.jpg'%b
    if not os.path.exists(out):
        im=Image.open(loc[b]).convert('RGB'); im.thumbnail((640,640)); im.save(out,quality=82)
    return 'img/%s.jpg'%b
FONT='<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;1,9..144,400;1,9..144,500&display=swap">'
for pre,name in (('a5-p','livret'),('ois-p','oiseaux')):
    files=sorted(f for f in os.listdir(SRCDIR) if f.startswith(pre))
    pages=[]
    for f in files:
        s=open(SRCDIR+'/'+f).read()
        body=s[s.index('</helmet>')+9:s.index('</x-dc>')]
        body=re.sub(r'/_blob/([0-9a-f]{32})',lambda m:small(m.group(1)),body)
        pages.append('<section class="pg">%s</section>'%body)
    html='<!doctype html><html lang="fr"><head><meta charset="utf-8">%s<style>@page{size:559px 794px;margin:0}html,body{margin:0;background:#fff}.pg{width:559px;height:794px;overflow:hidden;page-break-after:always;break-after:page}</style></head><body>%s</body></html>'%(FONT,''.join(pages))
    open('build/%s.html'%name,'w').write(html); print(name,len(pages))
