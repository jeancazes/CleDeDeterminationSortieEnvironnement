import re, json, os, shutil, subprocess
SPD=os.getcwd()
src=open('gen.py').read()
exec(src[:src.index('# ------------------------------------------------------------------ data')])
import parse_veg as P
P.L=L='out9/project/'
FILES=P.FILES={int(re.match(r'a5-p(\d+)',f).group(1)):f for f in os.listdir(L) if f.startswith('a5-p')}
def rd(name): return open(os.path.join(L,name)).read()
def rdp(p): return rd(FILES[p])
B={}
def wb(t):
    a,b,c,bl=t
    if bl: B['b:'+bl]=bl; return (a,b,c,'b:'+bl)
    return (a,b,c,None)
_opt=opt_html
def opt_html(letter,text,res,ctx):
    if res[0]!='ext': return _opt(letter,text,res,ctx)
    r=('<span style="display: inline-flex; align-items: center; gap: 4px; white-space: nowrap; font-weight: 700; font-size: 13.5px; border: 1.5px solid #1B1B18; '
       'border-radius: 5px; padding: 1px 7px; background: #F1F0EA">%s <span style="font-weight: 400; color: #55554F; font-size: 12.5px">p. %d</span></span>')%(res[1],res[2])
    base=_opt(letter,text,('go',0),dict(ctx,balpage={0:ctx['page']}))
    i=base.index('margin-bottom: 6px"></span>')+len('margin-bottom: 6px"></span>'); j=base.rindex('</div></div>')
    return base[:i]+r+base[j:]
def remap(p):
    if p<=25 or p>=62: return p
    if 26<=p<=57: return p+2
    if 58<=p<=61: return 60 if p in (58,60) else 61
    raise ValueError(p)
def remap_refs(s):
    s=re.sub(r'(font-weight: 700; font-size: 15px">)(\d+)(</div>)',lambda m:m.group(1)+str(remap(int(m.group(2))))+m.group(3),s)
    s=re.sub(r'(page |p\. )(\d+)',lambda m:m.group(1)+str(remap(int(m.group(2)))),s)
    return s
def number(sym, root):
    order=[]
    def walk(i):
        if i in order: return
        order.append(i)
        for t,r in sym[i]:
            if r[0]=='go': walk(r[1])
    walk(root)
    num={i:k+1 for k,i in enumerate(order)}
    return {num[i]:tuple((t,('go',num[r[1]]) if r[0]=='go' else r) for t,r in sym[i]) for i in order}
def remove_species(K,sp,name):
    rm=[n for n,v in sp.items() if re.sub('<[^>]+>','',v[0])==name]; assert len(rm)==1,name; rm=rm[0]
    K=dict(K)
    c=[n for n,cc in K.items() if any(r==('sp',rm) for t,r in cc)]; assert len(c)==1; c=c[0]
    other=[r for t,r in K[c] if r!=('sp',rm)][0]
    del K[c]
    K={n:tuple((t,other if r==('go',c) else r) for t,r in cc) for n,cc in K.items()}
    root=min(K) if c!=1 else (other[1] if other[0]=='go' else None)
    sp={n:v for n,v in sp.items() if n!=rm}
    order=sorted(sp); ren={o:i+1 for i,o in enumerate(order)}
    sp={ren[o]:v for o,v in sp.items()}
    K={n:tuple((t,('sp',ren[r[1]]) if r[0]=='sp' else r) for t,r in cc) for n,cc in K.items()}
    K=number(K,root if root else min(K))
    return K,sp
OLDTITLE={p:re.search(r'<title>(.*?)</title>',rdp(p)).group(1) for p in FILES}
NEW={}
# unchanged pages with refs remapped
for p in list(range(1,24))+list(range(26,58))+list(range(62,77)):
    NEW[remap(p)]=remap_refs(rdp(p))
# ---------- optimiser (from gen9)
def meas_heights(sections):
    meas=[]
    for name,(sp,K) in sections.items():
        names={n:v[0] for n,v in sp.items()}
        ctx=dict(page=-10,names=names,sppage={n:-9 for n in sp},balpage={n:-10 for n in K})
        for n in sorted(K): meas.append((name,n,couplet_html(n,K[n],False,ctx)))
    html='<html><head><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;1,9..144,400;1,9..144,500&display=swap"></head><body style="margin:0;font-family:\'Atkinson Hyperlegible\',\'Trebuchet MS\',sans-serif">'
    html+=''.join('<div class="m" style="width:467px;display:flex;flex-direction:column" data-k="%s|%d">%s</div>'%(a,n,h) for a,n,h in meas)+'</body></html>'
    open('build/meas.html','w').write(html); subprocess.run(['node','build/meas.js'],check=True)
    return {k:h for k,h in json.load(open('build/meas.json'))}
def optimise(name,sp,K,k,cap,H):
    cn=sorted(K); N=len(cn)
    h=[H['%s|%d'%(name,n)] for n in cn]
    res=[[x[1] for t,x in K[n] if x[0]=='sp'] for n in cn]
    def lim(i): return (702-124 if i==0 else 702-64) - (0 if i==k-1 else 24) - 8
    from functools import lru_cache
    @lru_cache(None)
    def dp(i,start):
        if i==k: return (0,()) if start==N else (1e9,())
        best=(1e9,()); tot=0
        for end in range(start+1,N+1):
            tot+=h[end-1]
            if tot>lim(i): break
            if k-i-1>N-end: break
            r=set(x for j in range(start,end) for x in res[j])
            c=max(0,len(r)-cap)*10+(30 if not r else 0)+((lim(i)-tot)/lim(i))**2*0.5
            sub=dp(i+1,end)
            if c+sub[0]<best[0]: best=(c+sub[0],(end-start,)+sub[1])
        return best
    cost,split=dp(0,0); assert split,name
    pages=[];idx=0;done=set()
    for s in split:
        lst=[]
        for j in range(idx,idx+s):
            for x in res[j]:
                if x not in done: done.add(x); lst.append(x)
        pages.append(lst); idx+=s
    pl=[l[:cap] for l in pages]
    for i,l in enumerate(pages):
        for x in l[cap:]:
            for d in (1,-1,2,-2,3,-3):
                j=i+d
                if 0<=j<k and len(pl[j])<cap: pl[j].append(x); break
    order=[x for l in pl for x in l]; ren={o:i+1 for i,o in enumerate(order)}
    sp2={ren[o]:sp[o] for o in sp}
    K2={n:tuple((t,('sp',ren[x[1]]) if x[0]=='sp' else x) for t,x in c) for n,c in K.items()}
    print(name,'split',split,'planches',[len(l) for l in pl],'hits',sum(1 for i in range(k) for x in pages[i] if x in pl[i]),'/',len(sp))
    return list(split),[len(l) for l in pl],sp2,K2
# ---------- forêt traces (old 36-41 -> 38-43) minus galle en corne
ts={n:wb(v) for n,v in P.species([37,39,41]).items()}; tk=P.couplets([36,38,40])
TK,TS=remove_species(tk,ts,'Galle en corne du térébinthe')
# ---------- ripi traces (old 58-61 -> 60-61) minus tronc rongé
rs={n:wb(v) for n,v in P.species([59,61]).items()}; rk=P.couplets([58,60])
RK,RS=remove_species(rk,rs,'Tronc rongé par le castor')
H=meas_heights({'ftra':(TS,TK)})
ks,ps,TS2,TK2=optimise('ftra',TS,TK,3,6,H)
f,_=build_section(dict(key1=FILES[36],keyN=FILES[38],pl1=FILES[37],plN=FILES[39]),[38,40,42],[39,41,43],TS2,TK2,ks,ps,"x","y")
for p,hh in f.items(): NEW[p]=re.sub(r'<title>.*?</title>','<title>%s</title>'%OLDTITLE[p-2],hh,count=1)
f,_=build_section(dict(key1=FILES[58],keyN=FILES[60],pl1=FILES[59],plN=FILES[61]),[60],[61],RS,RK,[len(RK)],[len(RS)],'Ripisylve : clé des traces','Ripisylve : planche des traces')
NEW.update(f)
# ---------- champignons (24-25) + lichens (26-27)
NS={n:wb(v) for n,v in P.species([25]).items()}; NK=P.couplets([24])
assert len(NS)==7 and len(NK)==6
f,_=build_section(dict(key1=FILES[24],keyN=FILES[8],pl1=FILES[25],plN=FILES[9]),[24,26],[25,27],NS,NK,[3,3],[3,4],
   "Forêt de l'Ancyse : champignons et lichens","Forêt de l'Ancyse : planche des champignons et des lichens")
PILL=rdp(24)[rdp(24).find('<span style="display: inline-flex; align-items: center; gap: 4px; padding: 3px 9px'):]
PILL=PILL[:PILL.find('</span>')+7]
PILLS=re.compile(r'(<span style="display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px 3px 6px.*?</svg>[^<]*</span>){3}',re.S)
for p in (26,27):
    h,k=PILLS.subn(PILL,f[p],count=1); assert k==1,p
    h=h.replace('>Clé des végétaux <span','>Ni plante, ni animal <span')
    h=h.replace('Planche des végétaux <span style="font-weight: 400; font-style: italic; color: #55554F">(suite)</span>','Planche des lichens')
    f[p]=h
f[25]=f[25].replace('>Champignons et lichens</h1>','>Planche des champignons</h1>').replace('>Planche des champignons et des lichens</h1>','>Planche des champignons</h1>')
assert 'Planche des lichens' in f[27] and 'Ni plante, ni animal' in f[26]
NEW.update(f)
# ---------- p75 mots
s=NEW[75]
for w in ('Empreinte','Insecte','Nom scientifique','Ripisylve'):
    s,k=re.subn(r'<div style="font-size: 14.5px; line-height: 1.4"><b>%s</b> : .*?</div>'%w,'',s); assert k==1,w
s=s.replace('gap: 7px">','gap: 10px">',1)
NEW[75]=s
assert sorted(NEW)==list(range(1,77)),[p for p in range(1,77) if p not in NEW]
# ---------- write out10 + canvas
OUT=SPD+'/out10/project'
if os.path.exists(SPD+'/out10'): shutil.rmtree(SPD+'/out10')
os.makedirs(OUT)
cj=json.load(open(L+'canvas.json'))
old_t={int(re.match(r'a5-p(\d+)',k).group(1)):v['title'].split(' · ',1)[1] for k,v in cj['boards'].items() if k.startswith('a5-')}
def t_of(p):
    if p==24: return 'Forêt : Champignons et lichens, clé (1/2)'
    if p==25: return 'Forêt : Planche des champignons'
    if p==26: return 'Forêt : Champignons et lichens, clé (2/2)'
    if p==27: return 'Forêt : Planche des lichens'
    if p==60: return 'Ripisylve : Clé des traces'
    if p==61: return 'Ripisylve : Planche des traces'
    if p<=23 or p>=62: return old_t[p]
    if 38<=p<=43: return 'Forêt : %s (%d/3)'%('Clé des traces' if p%2==0 else 'Planche des traces',(p-38)//2+1)
    return old_t[p-2]
slug=lambda t: re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',fr_key(t))).strip('-')
boards={k:v for k,v in cj['boards'].items() if not k.startswith('a5-')}
a5=[]
for p in range(1,77):
    t=t_of(p); fn='a5-p%02d-%s.dc.html'%(p,slug(t))
    open(os.path.join(OUT,fn),'w').write(NEW[p])
    boards[fn]={'x':639 if p%2 else 0,'y':914*(p//2),'w':559,'h':794,'title':'%02d · %s'%(p,t),'page':'a5'}; a5.append(fn)
cj['boards']=boards; cj['order']=a5+[k for k in cj['order'] if not k.startswith('a5-')]
json.dump(cj,open(OUT+'/canvas.json','w'),ensure_ascii=False,indent=1)
d={'project/'+f_:'project/'+f_ for f_ in a5 if not os.path.exists(L+f_) or open(L+f_).read()!=NEW[a5.index(f_)+1]}
d['project/canvas.json']='project/canvas.json'
for f_ in os.listdir(L):
    if f_.startswith('a5-') and f_ not in a5: d['project/'+f_]=None
json.dump(d,open('files10.json','w'),ensure_ascii=False)
print(len(d),'publish entries')
