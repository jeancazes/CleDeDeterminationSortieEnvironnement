import json,re,os,base64,html
from io import BytesIO
from PIL import Image
import parse_veg as P
P.L='out11/project/'
P.FILES={int(re.match(r'a5-p(\d+)',f).group(1)):f for f in os.listdir(P.L) if f.startswith('a5-p')}
loc=json.load(open('loc2.json'))
strip=lambda t: html.unescape(re.sub(r'\s+',' ',re.sub(r'<[^>]+>','',t))).strip()
SEC=[('foret','vegetaux',list(range(6,23,2)),list(range(7,24,2))),('foret','npa',[24,26],[25,27]),('foret','animaux',[28,30,32,34,36],[29,31,33,35,37]),('foret','traces',[38,40,42],[39,41,43]),
('ripi','vegetaux',list(range(44,55,2)),list(range(45,56,2))),('ripi','animaux',[56,58],[57,59]),('ripi','traces',[60],[61]),
('riv','vegetaux',[62,64],[63,65]),('riv','animaux',[66,68,70],[67,69,71]),('riv','traces',[72],[73])]
CARDP=re.compile(r'font-size: 12px">(\d+)</div><div style="flex-grow: 1')
imgs={}
def thumb(b):
    if b not in imgs:
        im=Image.open(loc[b]).convert('RGB'); im.thumbnail((420,420)); o=BytesIO(); im.save(o,'JPEG',quality=76,optimize=True)
        imgs[b]='data:image/jpeg;base64,'+base64.b64encode(o.getvalue()).decode()
    return imgs[b]
KEYS={}
def EXT(m,lab):
    if 'traces' in lab: return m+'-traces'
    if 'animaux' in lab or 'petites' in lab: return m+'-animaux'
    if 'Champignons' in lab: return 'foret-npa'
    raise ValueError(lab)
for m,k,kp,pp in SEC:
    sp=P.species(pp); cp=P.couplets(kp)
    page={}
    for p in pp:
        for n in CARDP.findall(open(P.L+P.FILES[p]).read()): page[int(n)]=p
    s=open(P.L+P.FILES[kp[0]]).read(); i=s.find('<h1'); h=s[i:i+1500]
    intro=strip(re.search(r'<p[^>]*>(.*?)</p>',h,re.S).group(1)) if re.search(r'<p[^>]*>(.*?)</p>',h,re.S) else ''
    KEYS[m+'-'+k]={'keyPage':kp[0],'intro':intro,
      'couplets':{str(n):[([strip(t),'ext',EXT(m,r[1]),strip(r[1]),r[2]] if r[0]=='ext' else [strip(t),r[0],r[1]]) for t,r in c] for n,c in cp.items()},
      'species':{str(n):{'name':strip(v[0]),'lat':strip(v[1]),'cap':strip(v[2]),'p':page[n],'img':thumb(v[3]) if v[3] else ''} for n,v in sp.items()}}
# version en ligne : clés complètes (avec les espèces retirées du livret papier)
FULL={'foret-traces':([36,38,40],[37,39,41]),'ripi-traces':([58,60],[59,61])}
P.L='out9/project/'; P.FILES={int(re.match(r'a5-p(\d+)',f).group(1)):f for f in os.listdir(P.L) if f.startswith('a5-p')}
for key,(kp,pp) in FULL.items():
    m=key.split('-')[0]
    sp=P.species(pp); cp=P.couplets(kp)
    pageof={v['name']:v['p'] for v in KEYS[key]['species'].values()}
    KEYS[key]['couplets']={str(n):[([strip(t),'ext',EXT(m,r[1]),strip(r[1]),r[2]] if r[0]=='ext' else [strip(t),r[0],r[1]]) for t,r in c] for n,c in cp.items()}
    KEYS[key]['species']={str(n):{'name':strip(v[0]),'lat':strip(v[1]),'cap':strip(v[2]),'p':pageof.get(strip(v[0]),0),'img':thumb(v[3]) if v[3] else ''} for n,v in sp.items()}
    print(key,'online-only:',[s['name'] for s in KEYS[key]['species'].values() if not s['p']])
ON=json.load(open('online11.json'))
for key,o in ON.items():
    m=key.split('-')[0]
    KEYS[key]['couplets']={n:[([c[0],'ext',EXT(m,c[2]),c[2],c[3]] if c[1]=='ext' else c) for c in cc] for n,cc in o['couplets'].items()}
    for n,s in o['extra'].items():
        KEYS[key]['species'][n]={'name':s['name'],'lat':s['lat'],'cap':s['cap'],'p':0,'img':thumb(s['blob']) if s['blob'] else ''}
    print(key,'online extra:',[s['name'] for s in o['extra'].values()])
json.dump(KEYS,open('keys_data.json','w'),ensure_ascii=False)
print(os.path.getsize('keys_data.json')/1e6,'MB', {k:len(v['species']) for k,v in KEYS.items()})
print(KEYS['riv-animaux']['intro'], '|', KEYS['foret-traces']['intro'])
