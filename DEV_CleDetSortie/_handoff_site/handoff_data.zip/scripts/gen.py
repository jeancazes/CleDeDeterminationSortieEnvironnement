import re, json, os, shutil, unicodedata
SP = '/tmp/claude-0/-home-claude/f62c4163-8c51-57da-bdfe-0bf0c9691cab/scratchpad'
SRC = SP + '/artifact-files/eee3db64-8039-4b59-a780-d902f58ce010/project'
OUT = SP + '/out'
PROJ = OUT + '/project'
B = json.load(open(SP + '/blobs.json'))

def rd(name):
    return open(os.path.join(SRC, name)).read()

old_files = sorted(f for f in os.listdir(SRC) if f.startswith('a5-p'))
OLD = {int(re.match(r'a5-p(\d+)', f).group(1)): f for f in old_files}

# ---------------------------------------------------------------- helpers
def remap(p):
    if p <= 5: return p
    if 12 <= p <= 19: return p + 2
    if p >= 24: return p + 6
    raise ValueError(p)

def remap_refs(s):
    s = re.sub(r'(font-weight: 700; font-size: 15px">)(\d+)(</div>)', lambda m: m.group(1) + str(remap(int(m.group(2)))) + m.group(3), s)
    s = re.sub(r'(page |p\. )(\d+)', lambda m: m.group(1) + str(remap(int(m.group(2)))), s)
    return s

def img(key):
    return '<img src="/_blob/%s" alt="" style="width: 100%%; height: 100%%; object-fit: contain; display: block">' % B[key]

PLACEHOLDER = ('<div style="width: 100%; height: 100%; box-sizing: border-box; border: 1.5px dashed #8A8A83; border-radius: 6px; '
               'display: flex; align-items: center; justify-content: center; font-size: 12px; color: #8A8A83; text-align: center">Illustration à venir</div>')

def swap_card_images(s, keys):
    """Replace the svg placeholder of the i-th card by keys[i]."""
    parts = re.split(r'(?=<div style="border: 1.5px solid #1B1B18; border-radius: 9px)', s)
    assert len(parts) - 1 == len(keys), (len(parts) - 1, len(keys))
    for i, k in enumerate(keys):
        parts[i + 1] = re.sub(r'<svg.*?</svg>', lambda m: img(k), parts[i + 1], count=1, flags=re.S)
    return ''.join(parts)

def fr_key(t):
    t = unicodedata.normalize('NFD', t)
    return ''.join(c for c in t if unicodedata.category(c) != 'Mn').lower()

# ------------------------------------------------ template pieces from old pages
def split_page(s):
    """returns (head, tabs, content_open, body, tail) around the content column."""
    i = s.find('<div style="position: absolute; top: 40px;')
    root_open_end = s.find('>', s.find('<div style="width: 559px')) + 1
    head = s[:root_open_end]
    tabs = s[root_open_end:i]
    return head, tabs, i

def header_of(s, kind):
    i = s.find('<div style="height: ')
    j = s.find('<div style="display: flex; flex-direction: column">' if kind == 'key' else '<div style="display: grid;', i)
    return s[i:j]

def page_skeleton(s):
    head, tabs, i = split_page(s)
    col_open_end = s.find('>', i) + 1
    col_open = s[i:col_open_end]
    tail = s[s.find('</x-dc>'):]
    return head, tabs, col_open, tail

def pagenum(n):
    side = 'left' if n % 2 == 0 else 'right'
    return '<div style="position: absolute; bottom: 20px; %s: 30px; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 15px">%d</div>' % (side, n)

def foot_note(n, text):
    if n % 2 == 0:
        return '<div style="position: absolute; bottom: 21px; right: 40px; text-align: right; font-size: 12.5px; color: #55554F">%s</div>' % text
    return '<div style="position: absolute; bottom: 21px; left: 40px; font-size: 12.5px; color: #55554F">%s</div>' % text

def set_title(head, title):
    return re.sub(r'<title>.*?</title>', '<title>%s</title>' % title, head)

# ------------------------------------------------ key + planche builders
BAL = ('<div style="width: 30px; height: 30px; box-sizing: border-box; border: 2px solid #1B1B18; border-radius: 6px; display: flex; align-items: center; '
       'justify-content: center; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 16px; background: #FFFFFF">%d</div>')
DASH = '<div style="flex-grow: 1; border-left: 2px dashed #8A8A83; margin-top: 3px"></div>'
PREF = '<span style="font-weight: 400; color: #55554F; font-size: 12.5px"> p. %d</span>'

def opt_html(letter, text, res, ctx):
    if res[0] == 'go':
        n = res[1]
        ref = PREF % ctx['balpage'][n] if ctx['balpage'][n] != ctx['page'] else ''
        r = ('<span style="display: inline-flex; align-items: center; gap: 5px; white-space: nowrap; font-size: 14px; color: #55554F">va à'
             '<span style="width: 21px; height: 21px; box-sizing: border-box; border: 1.5px solid #1B1B18; border-radius: 4px; display: inline-flex; '
             'align-items: center; justify-content: center; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 12.5px; color: #1B1B18">%d</span>%s</span>') % (n, ref)
    else:
        n = res[1]
        name = ctx['names'][n]
        pp = ctx['sppage'][n]
        ref = PREF % pp if pp != ctx['page'] + 1 else ''
        r = ('<span style="display: inline-flex; align-items: center; gap: 5px; border: 1.5px solid #1B1B18; border-radius: 999px; padding: 1px 9px 1px 2px; '
             'white-space: nowrap; font-weight: 700; font-size: 14px"><span style="width: 19px; height: 19px; border-radius: 50%%; background: #1B1B18; '
             'color: #FFFFFF; display: inline-flex; align-items: center; justify-content: center; font-family: \'Fraunces\', Georgia, serif; font-size: 11.5px">%d</span>%s%s</span>') % (n, name, ref)
    return ('<div style="display: flex; gap: 6px; font-size: 15px; line-height: 1.32"><span style="font-family: \'Fraunces\', Georgia, serif; font-style: italic; '
            'font-weight: 500; width: 12px; color: #55554F; flex-shrink: 0">%s</span><div style="flex-grow: 1; display: flex; flex-wrap: wrap; align-items: center; '
            'column-gap: 6px; row-gap: 2px"><span>%s</span><span style="flex-grow: 1; min-width: 10px; border-bottom: 1.5px dotted #8A8A83; align-self: flex-end; '
            'margin-bottom: 6px"></span>%s</div></div>') % (letter, text, r)

def couplet_html(n, c, last, ctx):
    return ('<div style="display: flex; gap: 14px"><div style="width: 30px; display: flex; flex-direction: column; align-items: center; flex-shrink: 0">'
            + BAL % n + ('' if last else DASH) + '</div><div style="flex-grow: 1; display: flex; flex-direction: column; gap: 5px; padding-top: 5px; padding-bottom: 11px">'
            + opt_html('a', c[0][0], c[0][1], ctx) + opt_html('b', c[1][0], c[1][1], ctx) + '</div></div>')

def card_html(n, sp):
    name, latin, cap, key = sp
    pic = img(key) if key else PLACEHOLDER
    return ('<div style="border: 1.5px solid #1B1B18; border-radius: 9px; display: flex; flex-direction: column; position: relative; min-height: 0; overflow: hidden; padding: 0 9px 8px">'
            '<div style="position: absolute; top: 7px; left: 7px; width: 22px; height: 22px; border-radius: 50%%; background: #1B1B18; color: #FFFFFF; display: flex; '
            'align-items: center; justify-content: center; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 12px">%d</div>'
            '<div style="flex-grow: 1; min-height: 0; position: relative"><div style="position: absolute; top: 20px; right: 2px; bottom: 3px; left: 2px">%s</div></div>'
            '<div style="font-size: 14.5px; font-weight: 700; line-height: 1.2">%s</div>'
            '<div style="font-family: \'Fraunces\', Georgia, serif; font-size: 13.5px; line-height: 1.3">%s</div>'
            '<div style="font-size: 13px; line-height: 1.25; color: #55554F">%s</div></div>') % (n, pic, name, latin, cap)

def build_section(tpl, key_pages, pl_pages, species, couplets, key_split, pl_split, title_key, title_pl):
    """tpl: dict with key1,keyN,pl1,plN old-file sources."""
    names = {n: sp[0] for n, sp in species.items()}
    sppage, balpage = {}, {}
    nums = sorted(species)
    idx = 0
    for pg, cnt in zip(pl_pages, pl_split):
        for n in nums[idx:idx + cnt]: sppage[n] = pg
        idx += cnt
    idx = 0
    cn = sorted(couplets)
    for pg, cnt in zip(key_pages, key_split):
        for n in cn[idx:idx + cnt]: balpage[n] = pg
        idx += cnt
    files = {}
    idx = 0
    for k, (pg, cnt) in enumerate(zip(key_pages, key_split)):
        src = rd(tpl['key1'] if k == 0 else tpl['keyN'])
        head, tabs, col_open, tail = page_skeleton(src)
        hdr = header_of(src, 'key')
        ctx = dict(page=pg, names=names, sppage=sppage, balpage=balpage)
        my = cn[idx:idx + cnt]; idx += cnt
        body = '<div style="display: flex; flex-direction: column">' + ''.join(couplet_html(n, couplets[n], i == len(my) - 1, ctx) for i, n in enumerate(my)) + '</div>'
        cont = ('<div style="margin-top: auto; font-size: 13px; color: #55554F">La clé continue page %d.</div>' % key_pages[k + 1]) if k < len(key_pages) - 1 else ''
        html = set_title(head, title_key) + tabs + col_open + hdr + body + cont + '</div>' + pagenum(pg) + foot_note(pg, 'Planche : page %d' % (pg + 1)) + '</div>\n' + tail
        files[pg] = html
    idx = 0
    for k, (pg, cnt) in enumerate(zip(pl_pages, pl_split)):
        src = rd(tpl['pl1'] if k == 0 else tpl['plN'])
        head, tabs, col_open, tail = page_skeleton(src)
        hdr = header_of(src, 'pl')
        my = nums[idx:idx + cnt]; idx += cnt
        rows = 3 if cnt > 4 else 2
        h = 578 if k == 0 else 638
        grid = ('<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); grid-template-rows: repeat(%d, minmax(0, 1fr)); gap: 10px; height: %dpx">' % (rows, h)
                + ''.join(card_html(n, species[n]) for n in my) + ('<div></div>' * (rows * 2 - cnt)) + '</div>')
        html = set_title(head, title_pl) + tabs + col_open + hdr + grid + '</div>' + pagenum(pg) + foot_note(pg, 'Clé : page %d' % (pg - 1)) + '</div>\n' + tail
        files[pg] = html
    return files, sppage

# ------------------------------------------------------------------ data
S = lambda l: '<i>%s</i>' % l
SSP = lambda g: '<i>%s</i> sp.' % g
FORET = {
 1: ("Pin d'Alep", S('Pinus halepensis'), 'Aiguilles fines par 2, petits cônes', 'b:900165b5cab9b19528f96df6d727295c'),
 2: ('Pin maritime', S('Pinus pinaster'), 'Aiguilles épaisses, gros cônes', 'b:c4143bef7a92d9560f4ba77a5c8acdcf'),
 3: ('Genévrier oxycèdre', S('Juniperus oxycedrus'), 'Aiguilles piquantes par 3', 'b:d15a1a787c14f4ff3718982877daeb8b'),
 4: ('Chêne vert', S('Quercus ilex'), 'Feuille dure, dessous gris', 'b:07d6e04ea42ea8f0d19839eb1dad1552'),
 5: ('Chêne pubescent', S('Quercus pubescens'), 'Feuille à lobes, duveteuse', 'b:4ec423e7cf88d5fa60c7194264cf8320'),
 6: ('Châtaignier', S('Castanea sativa'), 'Feuille dentée, bogues', 'b:4422687f457b070c7ed5ab2208e1ed3a'),
 7: ('Arbousier', S('Arbutus unedo'), 'Fruits rouges en octobre', 'b:d97061dfa4011c7ad09c805b7d058121'),
 8: ('Laurier-tin', S('Viburnum tinus'), 'Boules bleu métallique', 'b:2f35db2616c838cada1a8898f8634525'),
 9: ('Bruyère arborescente', S('Erica arborea'), 'Feuilles minuscules', 'b:13ee07cb41d427b025477cf01894dc47'),
 10: ('Ciste cotonneux', S('Cistus albidus'), 'Feuilles grises et douces', 'b:5e73cc61440ec7ed9da1e929a62be13b'),
 11: ('Ciste à feuilles de sauge', S('Cistus salviifolius'), 'Feuilles vertes et ridées', 'b:9f44eaca345f256e4b325b723b29067b'),
 12: ('Salsepareille', S('Smilax aspera'), 'Liane à épines', 'b:0ec5d2522e112e9568d960b2441e81e8'),
 13: ('Lierre', S('Hedera helix'), 'Grimpe avec des crampons', 'b:652dc165a2f9d4bbff9c09996d6a4969'),
 14: ('Thym', S('Thymus vulgaris'), 'Sent fort quand on le froisse', 'b:5c3ab28b282a47d4306ffd48d9a90543'),
 15: ('Chêne kermès', S('Quercus coccifera'), 'Feuilles piquantes, glands hérissés', None),
 16: ('Petit houx', S('Ruscus aculeatus'), '« Feuilles » piquantes, baie rouge', None),
 17: ('Asperge sauvage', S('Asparagus acutifolius'), "Bouquets d'aiguilles piquantes", None),
 18: ('Brachypode rameux', S('Brachypodium retusum'), 'Herbe de garrigue en touffes', None),
 19: ('Barbon pied-de-poule', S('Bothriochloa ischaemum'), 'Épis soyeux en éventail', None),
}
G = lambda n: ('go', n); R = lambda n: ('sp', n)
FORET_KEY = {
 1: (("La plante grimpe sur les arbres ou s'emmêle dans les buissons", G(2)), ('La plante tient debout toute seule', G(4))),
 2: (("Tiges couvertes de petits bouquets d'aiguilles piquantes", R(17)), ('Tiges avec de vraies feuilles larges', G(3))),
 3: (('Tige avec de petites épines, feuilles en cœur', R(12)), ('Tige sans épines, avec de petits crampons', R(13))),
 4: (('Herbe aux feuilles longues et étroites comme un ruban, avec des épis', G(5)), ('Plante avec des tiges en bois', G(6))),
 5: (('Épis fins et soyeux, groupés en éventail au bout de la tige', R(19)), ('1 à 3 épis plats et étroits au bout de tiges ramifiées', R(18))),
 6: (('Feuilles en aiguilles ou minuscules (moins de 1 cm)', G(7)), ('Feuilles plates et larges', G(11))),
 7: (('Aiguilles longues (plus de 5 cm), groupées par 2', G(8)), ('Aiguilles ou feuilles courtes (moins de 2 cm)', G(9))),
 8: (('Aiguilles fines et souples, cônes de 5 à 10 cm', R(1)), ('Aiguilles épaisses et raides, gros cônes pointus', R(2))),
 9: (('Aiguilles piquantes par 3, baies brun-rouge', R(3)), ('Feuilles minuscules qui ne piquent pas', G(10))),
 10: (('Arbuste de plus de 1 m, sans odeur', R(9)), ('Petite plante qui sent fort quand on la froisse', R(14))),
 11: (('Feuille molle, qui jaunit en octobre', G(12)), ('Feuille dure et épaisse, qui reste verte', G(13))),
 12: (('Feuille découpée en lobes arrondis, glands', R(5)), ('Longue feuille bordée de dents, bogues piquantes', R(6))),
 13: (('La feuille pique (épine au bout ou dents piquantes)', G(14)), ('La feuille ne pique pas', G(16))),
 14: (('Petite « feuille » ovale finie par une épine, baie rouge au milieu', R(16)), ('Feuille bordée de dents piquantes, glands', G(15))),
 15: (('Dessous de la feuille gris et duveteux', R(4)), ('Feuille luisante des 2 côtés, gland à cupule hérissée', R(15))),
 16: (('Feuilles collantes ou toutes douces, arbuste de moins de 1 m', G(17)), ('Feuilles lisses, ni collantes ni douces', G(18))),
 17: (('Feuilles gris clair, douces comme du velours', R(10)), ('Feuilles vertes, rugueuses et ridées', R(11))),
 18: (('Dessous de la feuille gris et duveteux, glands', R(4)), ('Dessous de la feuille vert', G(19))),
 19: (('Bord finement denté, fruits rouges granuleux', R(7)), ('Bord lisse, petites boules bleu métallique', R(8))),
}
RIPI = {
 1: ('Ronce', SSP('Rubus'), 'Aiguillons crochus, mûres', 'ripi-veg-01'),
 2: ('Clématite des haies', S('Clematis vitalba'), 'Fruits en plumets blancs', 'ripi-veg-02'),
 3: ('Houblon', S('Humulus lupulus'), 'Liane, cônes verts', 'ripi-veg-03'),
 4: ('Canne de Provence', S('Arundo donax'), "Tige creuse, jusqu'à 5 m", 'ripi-veg-04'),
 5: ('Frêne à feuilles étroites', S('Fraxinus angustifolia'), 'Feuille composée', 'ripi-veg-05'),
 6: ('Platane', S('Platanus × hispanica'), 'Écorce en plaques, boules', 'ripi-veg-06'),
 7: ('Saule blanc', S('Salix alba'), 'Feuille étroite, argentée', 'ripi-veg-07'),
 8: ('Aulne glutineux', S('Alnus glutinosa'), 'Feuille ronde, petits cônes', 'ripi-veg-08'),
 9: ('Peuplier blanc', S('Populus alba'), 'Dessous blanc cotonneux', 'ripi-veg-09'),
 10: ('Peuplier noir', S('Populus nigra'), 'Feuille en triangle ; dit « peuplier commun »', 'ripi-veg-10'),
 11: ('Carotte sauvage', S('Daucus carota'), 'Ombelle blanche, point sombre au centre', None),
 12: ("Ambroisie à feuilles d'armoise", S('Ambrosia artemisiifolia'), 'Envahissante, pollen très allergisant', None),
 13: ('Armoise commune', S('Artemisia vulgaris'), 'Dessous des feuilles blanc argenté', None),
 14: ('Datura', S('Datura stramonium'), 'Toxique : ne pas toucher', None),
 15: ('Bambou', SSP('Phyllostachys'), 'Espèce introduite, tige en bois', None),
 16: ('Peuplier tremble', S('Populus tremula'), 'Feuilles qui tremblent au vent', None),
 17: ('Liseron des haies', S('Calystegia sepium'), 'Grandes fleurs blanches en entonnoir', None),
 18: ('Dactyle aggloméré', S('Dactylis glomerata'), 'Épillets serrés en paquets', None),
 19: ('Chiendent pied-de-poule', S('Cynodon dactylon'), 'Épis fins en étoile, tiges qui rampent', None),
}
RIPI_KEY = {
 1: (('La plante grimpe ou retombe sur les autres', G(2)), ('La plante tient debout toute seule', G(5))),
 2: (('Tiges avec des aiguillons crochus, mûres', R(1)), ("Pas d'aiguillons", G(3))),
 3: (('Fruits en plumets blancs et soyeux', R(2)), ('Pas de plumets', G(4))),
 4: (('Tige lisse qui s\'enroule, grandes fleurs blanches en entonnoir', R(17)), ('Tige rugueuse qui accroche, petits cônes verts pâles', R(3))),
 5: (('Tige creuse avec des nœuds, feuilles longues comme des rubans', G(6)), ('Autre plante', G(9))),
 6: (('Plus de 2 m, tige grosse comme un doigt ou plus', G(7)), ('Petite herbe de moins de 1 m', G(8))),
 7: (('Feuilles collées à la tige sur 2 rangs, grand plumeau au sommet', R(4)), ('Tige dure et lisse, 2 rameaux à chaque nœud', R(15))),
 8: (('Épillets serrés en paquets denses, touffe dressée', R(18)), ('Épis fins en étoile, tiges qui rampent au sol', R(19))),
 9: (('Arbre avec un tronc en bois', G(13)), ('Herbe sans tronc en bois', G(10))),
 10: (('Grande fleur blanche en trompette ou fruit hérissé d\'épines', R(14)), ('Fleurs minuscules', G(11))),
 11: (('Fleurs en ombelle plate, ou fruits en « nid d\'oiseau »', R(11)), ('Fleurs en épis, feuilles très découpées', G(12))),
 12: (('Dessous de la feuille blanc argenté', R(13)), ('Feuille verte des 2 côtés, tige velue', R(12))),
 13: (('Feuille faite de plusieurs folioles alignées', R(5)), ("Feuille d'une seule pièce", G(14))),
 14: (('Écorce en plaques, feuille en main à 5 pointes', R(6)), ('Écorce ordinaire', G(15))),
 15: (('Feuille longue et étroite, dessous argenté', R(7)), ('Feuille plus large', G(16))),
 16: (('Feuille ronde au bout échancré, petits cônes', R(8)), ('Autre forme de feuille', G(17))),
 17: (('Dessous de la feuille blanc et cotonneux', R(9)), ('Dessous de la feuille vert', G(18))),
 18: (('Feuille presque ronde à grosses dents, longue queue aplatie', R(16)), ('Feuille en triangle, verte des 2 côtés', R(10))),
}

def fix_imgs(d):
    for n, sp in d.items():
        k = sp[3]
        if k and k.startswith('b:'):
            B['__' + k[2:]] = k[2:]
            d[n] = sp[:3] + ('__' + k[2:],)

fix_imgs(FORET)

os.makedirs(PROJ, exist_ok=True)
NEW = {}

# forêt végétaux
f, FORET_PG = build_section(dict(key1=OLD[6], keyN=OLD[8], pl1=OLD[7], plN=OLD[9]), [6, 8, 10, 12], [7, 9, 11, 13], FORET, FORET_KEY,
                            [5, 5, 5, 4], [5, 5, 5, 4], "Forêt de l'Ancyse : clé des végétaux", "Forêt de l'Ancyse : planche des végétaux")
NEW.update(f)
f, RIPI_PG = build_section(dict(key1=OLD[20], keyN=OLD[22], pl1=OLD[21], plN=OLD[23]), [22, 24, 26, 28], [23, 25, 27, 29], RIPI, RIPI_KEY,
                           [5, 5, 4, 4], [5, 5, 5, 4], 'Ripisylve : clé des végétaux', 'Ripisylve : planche des végétaux')
NEW.update(f)

# pages that only move / get images
IMG_KEYS = {
 13: None, 15: ['__0fab90d5a4edfab23dd142a64dbc64ca'] * 0,
}
card_keys = {
 17: ['foret-tra-%02d' % i for i in range(1, 7)],
 19: ['foret-tra-%02d' % i for i in range(7, 13)],
 25: ['ripi-ani-%02d' % i for i in range(1, 5)],
 27: ['ripi-ani-%02d' % i for i in range(5, 9)],
 29: ['ripi-tra-%02d' % i for i in range(1, 5)],
 31: ['ripi-tra-%02d' % i for i in range(5, 8)],
 33: ['riv-veg-%02d' % i for i in range(1, 5)],
 35: ['riv-veg-%02d' % i for i in range(5, 9)],
 37: ['riv-ani-%02d' % i for i in range(1, 7)],
 39: ['riv-ani-%02d' % i for i in range(7, 13)],
 41: ['riv-ani-%02d' % i for i in range(13, 19)],
 43: ['riv-tra-%02d' % i for i in range(1, 7)],
}
QE = {'Larve de plécoptère': 'riv-ani-16', "Larve d'éphémère": 'riv-ani-15', 'Larve de trichoptère': 'riv-ani-11', 'Ancyle': 'riv-ani-02',
      'Gammare': 'riv-ani-09', 'Larve de demoiselle': 'riv-ani-17', 'Larve de libellule': 'riv-ani-18', 'Limnée': 'riv-ani-03',
      'Larve de chironome': 'riv-ani-05', 'Sangsue': 'riv-ani-06', 'Aselle': 'riv-ani-10', 'Physe': 'riv-ani-04'}

for old in list(range(12, 20)) + list(range(24, 47)):
    s = rd(OLD[old])
    if old in card_keys:
        s = swap_card_images(s, card_keys[old])
    if old == 15:  # mante religieuse v2
        s = s.replace('/_blob/b358403c690660c048904ccb0e4f824a', '/_blob/' + B['foret-ani-12'])
    if old in (44, 45):
        def qe(m):
            lab = re.sub(r'<[^>]+>', '', '<' + m.group(2)).strip()
            return m.group(1) + img(QE[lab]) + '</div><span' + m.group(2)
        s, k = re.subn(r'(<div style="width: 90px; height: 62px">)<svg.*?</svg></div><span(.*?</span>)', qe, s, flags=re.S)
        assert k in (8, 4), (old, k)
    s = remap_refs(s)
    NEW[remap(old)] = s

# rules + sommaire (p5)
s = rd(OLD[5])
s = s.replace("Je ne touche pas les chenilles processionnaires ni leurs nids.", "Je ne touche pas les chenilles processionnaires, leurs nids, ni le datura (voir page 56).")
SOM = {('p. 6', 'p. 12', 'p. 16'): ('p. 6', 'p. 14', 'p. 18'), ('p. 20', 'p. 24', 'p. 28'): ('p. 22', 'p. 30', 'p. 34'), ('p. 32', 'p. 36', 'p. 42'): ('p. 38', 'p. 42', 'p. 48')}
rows = re.findall(r'<tr>.*?</tr>', s, flags=re.S)
def fixrow(r, a, b):
    for x, y in zip(a, b):
        r = r.replace('">%s</td>' % x, '">@@%s</td>' % y, 1)
    return r.replace('@@', '')
for r in rows:
    nr = r
    for a, b in SOM.items():
        if all(('">%s</td>' % x) in r for x in a):
            nr = fixrow(r, a, b)
    nr = nr.replace('">p. 44</td>', '">p. 50</td>').replace('">p. 46</td>', '">p. 52</td>').replace('">p. 47</td>', '">p. 53</td>')
    s = s.replace(r, nr)
last_row = rows[-1]
td_l = re.search(r'<td[^>]*colspan="3">', last_row).group(0)
td_r = re.findall(r'<td[^>]*>', last_row)[-1]
s = s.replace('</tbody>', '<tr>' + td_l + 'À ne pas toucher</td>' + td_r + 'p. 56</td></tr></tbody>')
NEW[5] = s
for p in (1, 2, 3, 4):
    NEW[p] = rd(OLD[p])

# mots à connaître (p52)
s = rd(OLD[46])
ENTRY = '<div style="font-size: 14.5px; line-height: 1.4"><b>%s</b> : %s</div>'
entries = re.findall(r'<div style="font-size: 14.5px; line-height: 1.4"><b>(.*?)</b> : (.*?)</div>', s)
entries += [('Espèce envahissante', 'espèce introduite qui se répand vite et prend la place des espèces locales.'),
            ('Graminée', "plante aux feuilles longues et étroites comme un ruban et aux fleurs en épis, comme le blé."),
            ('Ombelle', "groupe de fleurs dont les queues partent toutes du même point, comme les baleines d'un parapluie.")]
entries.sort(key=lambda e: fr_key(e[0]))
blk = re.search(r'(<div style="margin-top: 14px; display: flex; flex-direction: column; gap: 9px">)(.*?)(</div></div><div style="position: absolute; bottom: 20px)', s, flags=re.S)
s = s[:blk.start(2)] + ''.join(ENTRY % e for e in entries) + s[blk.end(2):]
s = s.replace('font-size: 15px">46</div>', 'font-size: 15px">52</div>')
NEW[52] = s

# index (p53-55)
idx_src = rd(OLD[47]) + rd(OLD[48])
entries = re.findall(r'<span>([^<]+)</span><span style="flex-grow: 1; min-width: 6px[^>]*></span><span style="white-space: nowrap; font-size: 12.5px">n° (\d+), <b>p\. (\d+)</b></span>', idx_src)
ent = []
for name, n, p in entries:
    p = int(p)
    if p in (7, 9, 11, 21, 23):
        continue
    ent.append((name, int(n), remap(p)))
for n, sp in FORET.items(): ent.append((sp[0], n, FORET_PG[n]))
for n, sp in RIPI.items(): ent.append((sp[0], n, RIPI_PG[n]))
ent.sort(key=lambda e: fr_key(e[0]))
print('index entries', len(ent))
IE = ('<div style="display: flex; align-items: baseline; gap: 4px; font-size: 13px; line-height: 1.25"><span>%s</span><span style="flex-grow: 1; min-width: 6px; '
      'border-bottom: 1.5px dotted #8A8A83; align-self: flex-end; margin-bottom: 4px"></span><span style="white-space: nowrap; font-size: 12.5px">n° %d, <b>p. %d</b></span></div>')
COL = '<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px">'
p47 = rd(OLD[47]); p48 = rd(OLD[48])
def index_page(src, pg, items, head_html):
    head, tabs, col_open, tail = page_skeleton(src)
    half = (len(items) + 1) // 2
    cols = '<div style="display: flex; gap: 18px">' + COL + ''.join(IE % e for e in items[:half]) + '</div>' + COL + ''.join(IE % e for e in items[half:]) + '</div></div>'
    return head + tabs + col_open + head_html + cols + '</div>' + pagenum(pg) + '</div>\n' + tail
h47 = re.search(r'(<h1.*?</p>)', p47, flags=re.S).group(1)
i48 = p48.find('<div style="position: absolute; top: 40px'); i48 = p48.find('>', i48) + 1
h48 = p48[i48:p48.find('<div style="display: flex; gap: 18px">', i48)]
n1 = 36; n2 = 37
parts = [ent[:n1], ent[n1:n1 + n2], ent[n1 + n2:]]
# page 53 is odd (right), 54 even (left), 55 odd (right): p47 is odd, p48 even
NEW[53] = index_page(p47, 53, parts[0], h47)
NEW[54] = index_page(p48, 54, parts[1], h48)
NEW[55] = index_page(p47, 55, parts[2], h48)
print([len(x) for x in parts])
json.dump(dict(foret=FORET_PG, ripi=RIPI_PG), open(SP + '/pages.json', 'w'))

# p56 : à ne pas toucher
src = rd(OLD[46])  # even page, no tabs
head, tabs, col_open, tail = page_skeleton(src)
def warn(key, name, why):
    pic = img(key) if key else PLACEHOLDER
    return ('<div style="display: flex; gap: 12px; align-items: center; border: 1.5px solid #1B1B18; border-radius: 9px; padding: 8px 10px">'
            '<div style="width: 96px; height: 70px; flex-shrink: 0">%s</div><div style="display: flex; flex-direction: column; gap: 2px">'
            '<div style="font-size: 14.5px; font-weight: 700">%s</div><div style="font-size: 13.5px; line-height: 1.3; color: #1B1B18">%s</div></div></div>') % (pic, name, why)
W = [('__0780224a3e62177b139a3404ebb265ab', 'Chenille processionnaire (forêt)', 'Ses poils piquent la peau et les yeux, même sans la toucher. On ne touche ni les chenilles ni leur nid.'),
     ('foret-tra-08', 'Nid de processionnaire (forêt)', 'Il reste plein de poils urticants. On le regarde de loin.'),
     (None, 'Datura (ripisylve)', 'Toute la plante est très toxique. On ne la touche pas et on ne porte jamais les mains à la bouche.'),
     (None, 'Ambroisie (ripisylve)', "Son pollen provoque des allergies en fin d'été. On ne la secoue pas."),
     ('riv-ani-12', 'Notonecte (rivière)', "Elle peut piquer le doigt. On l'observe dans le bac, sans la prendre."),
     ('riv-veg-05', 'Cresson de fontaine (rivière)', "Il peut porter un parasite du foie. On ne le mange pas.")]
B['__0780224a3e62177b139a3404ebb265ab'] = '0780224a3e62177b139a3404ebb265ab'
body = ('<h1 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 29px; line-height: 1.05">À ne pas toucher</h1>'
        '<p style="margin: 6px 0 14px; font-size: 14px; line-height: 1.35; color: #55554F">Quelques espèces du livret peuvent piquer, irriter ou empoisonner. En cas de doute, on demande à l\'adulte.</p>'
        '<div style="display: flex; flex-direction: column; gap: 9px">' + ''.join(warn(*w) for w in W) + '</div>')
NEW[56] = set_title(head, 'À ne pas toucher') + tabs + col_open + body + '</div>' + pagenum(56) + '</div>\n' + tail

# ------------------------------------------------------------------ write + canvas
TITLES = {}
slug = lambda t: re.sub(r'-+', '-', re.sub(r'[^a-z0-9]+', '-', fr_key(t))).strip('-')
names_old = json.load(open(SRC + '/canvas.json'))
old_titles = {int(re.match(r'a5-p(\d+)', k).group(1)): v['title'] for k, v in names_old['boards'].items() if k.startswith('a5-')}
def t_of(p):
    if p <= 5: return old_titles[p].split(' · ', 1)[1]
    sec = {6: 'Forêt : Clé des végétaux', 7: 'Forêt : Planche des végétaux', 22: 'Ripisylve : Clé des végétaux', 23: 'Ripisylve : Planche des végétaux'}
    if 6 <= p <= 13:
        base = sec[6] if p % 2 == 0 else sec[7]; return '%s (%d/4)' % (base, (p - 6) // 2 + 1)
    if 22 <= p <= 29:
        base = sec[22] if p % 2 == 0 else sec[23]; return '%s (%d/4)' % (base, (p - 22) // 2 + 1)
    if p == 52: return 'Mots à connaître'
    if p in (53, 54, 55): return 'Index des espèces (%d/3)' % (p - 52)
    if p == 56: return 'À ne pas toucher'
    inv = {remap(o): o for o in list(range(12, 20)) + list(range(24, 47))}
    return old_titles[inv[p]].split(' · ', 1)[1]
if os.path.exists(OUT): shutil.rmtree(OUT)
os.makedirs(PROJ)
boards = {k: v for k, v in names_old['boards'].items() if not k.startswith('a5-')}
order = [k for k in names_old['order'] if not k.startswith('a5-')]
for p in range(1, 57):
    t = t_of(p)
    fn = 'a5-p%02d-%s.dc.html' % (p, slug(t))
    open(os.path.join(PROJ, fn), 'w').write(NEW[p])
    boards[fn] = {'x': 639 if p % 2 else 0, 'y': 914 * (p // 2), 'w': 559, 'h': 794, 'title': '%02d · %s' % (p, t), 'page': 'a5'}
    order.append(fn)
cj = dict(names_old); cj['boards'] = boards; cj['order'] = order
json.dump(cj, open(PROJ + '/canvas.json', 'w'), ensure_ascii=False, indent=1)
new_names = set(f for f in os.listdir(PROJ) if f.startswith('a5-'))
removed = [f for f in old_files if f not in new_names]
json.dump(removed, open(SP + '/removed.json', 'w'))
print('written', len(new_names), 'removed', len(removed))
